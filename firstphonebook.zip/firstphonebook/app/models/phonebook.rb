class Phonebook < ApplicationRecord
end
