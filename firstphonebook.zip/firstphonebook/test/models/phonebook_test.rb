require 'test_helper'

class PhonebookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
