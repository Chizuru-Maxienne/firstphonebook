require "application_system_test_case"

class PhonebooksTest < ApplicationSystemTestCase
  setup do
    @phonebook = phonebooks(:one)
  end

  test "visiting the index" do
    visit phonebooks_url
    assert_selector "h1", text: "Phonebooks"
  end

  test "creating a Phonebook" do
    visit phonebooks_url
    click_on "New Phonebook"

    fill_in "Address", with: @phonebook.address
    fill_in "Name", with: @phonebook.name
    fill_in "Number", with: @phonebook.number
    click_on "Create Phonebook"

    assert_text "Phonebook was successfully created"
    click_on "Back"
  end

  test "updating a Phonebook" do
    visit phonebooks_url
    click_on "Edit", match: :first

    fill_in "Address", with: @phonebook.address
    fill_in "Name", with: @phonebook.name
    fill_in "Number", with: @phonebook.number
    click_on "Update Phonebook"

    assert_text "Phonebook was successfully updated"
    click_on "Back"
  end

  test "destroying a Phonebook" do
    visit phonebooks_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Phonebook was successfully destroyed"
  end
end
