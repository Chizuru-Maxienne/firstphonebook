class CreatePhonebooks < ActiveRecord::Migration[5.2]
  def change
    create_table :phonebooks do |t|
      t.string :name
      t.text :address
      t.integer :number

      t.timestamps
    end
  end
end
