Rails.application.routes.draw do
  resources :phonebooks
  root 'phonebooks#index'
  post 'phonebooks/edit' => 'phonebooks#edit'
   get 'phonebooks/show' => 'phonebooks#show'
  post 'phonebooks/create' => 'phonebooks#create'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
